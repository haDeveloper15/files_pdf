<?php

namespace Arphp;

include_once __DIR__ .'/../../I18N/Arabic/CharsetC.php';

class CharsetC extends \I18N_Arabic_CharsetC {
    
}
