<?php

namespace Arphp;

include_once __DIR__ .'/../../I18N/Arabic/Soundex.php';

class Soundex extends \I18N_Arabic_Soundex {
    
}
