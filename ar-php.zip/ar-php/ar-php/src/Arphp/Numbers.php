<?php

namespace Arphp;

include_once __DIR__ .'/../../I18N/Arabic/Numbers.php';

class Numbers extends \I18N_Arabic_Numbers {
    
}
