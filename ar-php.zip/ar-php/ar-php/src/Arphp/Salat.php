<?php

namespace Arphp;

include_once __DIR__ .'/../../I18N/Arabic/Salat.php';

class Salat extends \I18N_Arabic_Salat {
    
}
