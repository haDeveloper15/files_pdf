<?php

namespace Arphp;

include_once __DIR__ .'/../../I18N/Arabic/StrToTime.php';

class StrToTime extends \I18N_Arabic_StrToTime {
    
}
