<?php

namespace Arphp;

include_once __DIR__ . '/../../I18N/Arabic/Transliteration.php';

class Transliteration extends \I18N_Arabic_Transliteration {
    
}
