<?php

namespace Arphp;

include_once __DIR__ .'/../../I18N/Arabic/Identifier.php';

class Identifier extends \I18N_Arabic_Identifier {

}
