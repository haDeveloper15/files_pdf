<?php

namespace Arphp;

include_once __DIR__ .'/../../I18N/Arabic/Glyphs.php';

class Glyphs extends \I18N_Arabic_Glyphs {
    
}
