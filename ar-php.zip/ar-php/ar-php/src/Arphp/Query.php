<?php

namespace Arphp;

include_once __DIR__ .'/../../I18N/Arabic/Query.php';

class Query extends \I18N_Arabic_Query {
    
}
