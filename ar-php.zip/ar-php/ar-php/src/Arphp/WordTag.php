<?php

namespace Arphp;

include_once __DIR__ .'/../../I18N/Arabic/WordTag.php';

class WordTag extends \I18N_Arabic_WordTag {
    
}
