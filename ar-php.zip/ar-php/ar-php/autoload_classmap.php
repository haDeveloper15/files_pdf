<?php

return array(
    "Arphp\AutoSummarize"     => __DIR__ . "src/Arphp/AutoSummarize.php",
    "Arphp\CharsetC"          => __DIR__ . "src/Arphp/CharsetC.php",
    "Arphp\CharsetD"          => __DIR__ . "src/Arphp/CharsetD.php",
    "Arphp\CompressStr"       => __DIR__ . "src/Arphp/CompressStr.php",
    "Arphp\Date"              => __DIR__ . "src/Arphp/Date.php",
    "Arphp\Gender"            => __DIR__ . "src/Arphp/Gender.php",
    "Arphp\Glyphs"            => __DIR__ . "src/Arphp/Glyphs.php",
    "Arphp\Hiero"             => __DIR__ . "src/Arphp/Hiero.php",
    "Arphp\Identifier"        => __DIR__ . "src/Arphp/Identifier.php",
    "Arphp\KeySwap"           => __DIR__ . "src/Arphp/KeySwap.php",
    "Arphp\Mktime"            => __DIR__ . "src/Arphp/Mktime.php",
    "Arphp\Normalise"         => __DIR__ . "src/Arphp/Normalise.php",
    "Arphp\Numbers"           => __DIR__ . "src/Arphp/Numbers.php",
    "Arphp\Query"             => __DIR__ . "src/Arphp/Query.php",
    "Arphp\Salat"             => __DIR__ . "src/Arphp/Salat.php",
    "Arphp\Soundex"           => __DIR__ . "src/Arphp/Soundex.php",
    "Arphp\Standard"          => __DIR__ . "src/Arphp/Standard.php",
    "Arphp\Stemmer"           => __DIR__ . "src/Arphp/Stemmer.php",
    "Arphp\Transliteration"   => __DIR__ . "src/Arphp/Transliteration.php",
    "Arphp\WordTag"           => __DIR__ . "src/Arphp/WordTag.php",
    "Arphp\StrToTime"         => __DIR__ . "src/Arphp/StrToTime.php"
);
